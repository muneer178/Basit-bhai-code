<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php

$host = "localhost";
$username = "root";
$password = "";

$conn = new mysqli($host , $username , $password);

if($conn){
    echo "Connection is Sucessfully <br>";
}

else{
    echo "Connection error";
}


$arr = array("Muneer Ahmed" => "Black" , "M.Hamza" => "Blue" , "Shakeel Ahmed" => "Pink");

// echo $arr['Muneer Ahmed'];
// echo "<br>";
// echo $arr['M.Hamza'];
// echo "<br>";
// echo $arr['Shakeel Ahmed'];

// USE FOREACH LOOP WITH ASSOCIATIVE ARRAY//

foreach ($arr as $key => $value) {
    echo "<br> favourite color of $key is $value <br>";
}




?>
</body>
</html>