<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<?php


    $host = "localhost";
    $username = "root";
    $password = "";


    //USE CONNECTION QUERY//

    $conn = mysqli_connect($host , $username , $password);

    if(!$conn){
        die("sorry connection failed" . mysqli_connect_error());
    }

    else{
      echo  "Connection was Sucessfull";
    }

?>
</body>
</html>