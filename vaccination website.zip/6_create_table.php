<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    

    <?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "newdatabase";


    $conn = Mysqli_Connect($servername , $username , $password , $database);

    if(!$conn){
        die("Oops Connection Failed" . mysqli_connect_error());
    }

    else{
        echo "Connection Sucessfully";
    }


    $sql = "CREATE TABLE `table1` (`s.no` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(15) NOT NULL , `fname` VARCHAR(15) NOT NULL)";

    $result = Mysqli_query($conn ,$sql);

    if($result){
        echo "Table Created Sucessfully";
        }
        else{
            echo "Table did not created Sucessfully";
        }
    ?>
</body>
</html>