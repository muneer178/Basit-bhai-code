<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

        <?php


$host = "localhost";
$username = "root";
$password = "";
// $databse = ""


$conn = new mysqli($host , $username , $password);

if($conn){
    echo "Connection is Sucessful" . "<br>";
}

else{
    echo "Connection Failed";
}
 


// USE WHILE LOOP 
/*
$i = 0;

while($i<10){
    echo $i+1;
    echo "<br>";
   $i++;
}
*/


// USE FOR LOOP
/*
     for($i = 0 ; $i < 10 ; $i++){
     echo "<br>" . $i+1;
     } */




// USE DO WHILE LOOP

/*
$i = 0;

  do{
     echo $i+1;
     echo "<br>";
     $i++;
  }

  while($i < 10)
*/




// FOREACH LOOP


// $arr = array("Muhammad Hamza" , "Shakeel Ahmed" , "Muneer Ahmed");

// foreach ($arr as $value) {
//     echo "$value . <br>";
// }





?>
    
</body>
</html>