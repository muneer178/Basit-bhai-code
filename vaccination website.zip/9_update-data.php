<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php

        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "contact";


        $conn = Mysqli_connect($servername , $username , $password , $database);

        if($conn){
            echo "Connection is Sucessfully";

        }

        else{
            echo "Connection Failed";

        }

        $sql = "UPDATE `contactus` SET `name` = 'Muhammad' WHERE id = 3";
        $result = Mysqli_query($conn , $sql);

        if($result){
            echo "<br> Data is Updated";

        }

        else{
            echo "Data is not Updated due to some issues";
        }

    ?>
</body>
</html>