<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "contact";

    $conn = Mysqli_connect($servername , $username , $password , $database);

    if($conn){
        echo "Connection Successfully";

    }
    else{
     echo "Connection is Error";    
    }

    $sql = "SELECT * FROM `contactus`";
    $result = Mysqli_query($conn , $sql);
    $num = mysqli_num_rows($result);
 
    if($num > 0 ){

        while($row = mysqli_fetch_assoc($result)){
            echo "<br>";
            echo $row['id'] . " . Hello " . $row['name'] . " and " . $row['email'] . " and batch is: " . $row['batch'];
        }

    }
    ?>
</body>
</html>