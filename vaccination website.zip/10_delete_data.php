<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "contact";

    $conn = Mysqli_connect($servername , $username , $password , $database);
    if($conn){
        echo "Connection is Successfully";

    }
    else{
        echo "Connection Failed";
    }


    $sql = "DELETE FROM `contactus` WHERE id = 9";
    $result = Mysqli_query($conn , $sql);

    if($result){
        echo "Data is Deleted";
    }
    else{
        echo "Data is not Deleted";
    }
    ?>
</body>
</html>