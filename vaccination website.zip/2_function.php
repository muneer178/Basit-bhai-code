<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <?php

        $host = "localhost";
        $username = "root";
        $password = "";
        
        $conn = new mysqli($host , $username , $password);

        if($conn){
            echo "Connection is Sucessfully <br>";
        }

        else{
            echo "Connection error";
        }



   

    
    function func($Muneer){
        echo "$Muneer  Asslam Alaikum";
    }

    func("Muneer"); echo "<br>";
    func("Muhammad Hamza"); echo "<br>";
    func("Shakeel Ahmed"); echo "<br>";
    func("Irfan Ali"); echo "<br>";

?>